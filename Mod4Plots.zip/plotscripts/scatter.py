import pandas as pd
import matplotlib.pyplot as plt
import sys
#create dataframe from csv link https://data.gov.in/catalog/roc-wise-statistics-prosecutions
df=pd.read_csv(sys.argv[1])
df1=df[['Name of ROC','Cases out standing as on 1.4.2013','Number of cases pending as on 31.3.2014']]

plt.scatter(df1[:-1]['Cases out standing as on 1.4.2013'],df1[:-1]['Number of cases pending as on 31.3.2014'],label="Data Points")

#specifying labels

plt.xlabel("Cases out standing as on 1.4.2013")

plt.ylabel("Number of cases pending as on 31.3.2014")
plt.title("Cases pending at start vs Cases pending at the end of the Financial year 2013-2014")
#enable legend

plt.legend()

plt.show()