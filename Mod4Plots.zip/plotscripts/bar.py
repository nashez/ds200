import pandas as pd

import matplotlib.pyplot as plt

import sys

#reading data frame from a csv file link https://data.gov.in/resources/economic-activity-wise-active-government-companies-31st-march-2014

df=pd.read_csv(sys.argv[1])
df1=df[['SECTOR','No. of Companies - Total']]
df2=df1.drop(df1.index[[2,3,4,5,7,8,9,10,11,12,13,15]])
#plot bar plot with xticks which is position of bars as first argument and height of bars as second argument

plt.bar(df2['SECTOR'],df2['No. of Companies - Total'],color='#ddbbaa')

#specify labels on xticks

plt.xlabel("Sector")
plt.ylabel("Total No. of Companies")
plt.title("Total Number of Companies in each Sector")

plt.show()