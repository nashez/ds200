
import pandas as pd

import matplotlib.pyplot as plt

import sys



#creating dataframe

df=pd.read_csv(sys.argv[1])
df1=df[['Category','Approved','Approved Rooms']]
ind=[1,3,5,7,9,11]

width=0.35

#plotting first type of bars

plt.bar(ind,df['Approved'],width,color='#ddbbaa',label=df1['Category'])

#plotting second type of bars

plt.bar([x+width for x in ind],df['Approved Rooms'],width,color='#ddffaa',label=df1['Category'])



#specifying labels

plt.xticks([1,3,5,7,9,11],["BarPlot1","BarPlot2","BarPlot3","BarPlot4","BarPlot5","BarPlot6"])

plt.xlabel("Category of Hotel")

plt.ylabel("Value in Integers")



#enabling legend

plt.legend()

plt.show()