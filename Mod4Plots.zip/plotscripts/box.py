import pandas as pd
import matplotlib.pyplot as plt
import sys
#create dataframe from csv link https://data.gov.in/resources/foreign-tourist-arrivals-india-top-15-source-countries-2001-2015
df=pd.read_csv(sys.argv[1])
df1=df[['2001','2002','2003','2004','2005','2006','2007','2008','2009','2010','2011','2012','2013','2014','2015']]

df1[:-2].boxplot()
plt.ylabel("Number of Tourists from different countries")
plt.xlabel("Year")
plt.title("Tourists from different countries: Box Plot every year")

plt.show()